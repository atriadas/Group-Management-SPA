export  class CustomerList{
    arr = []
    arr2 = []
    memberLength:number;
    managerLength:number;
    constructor(arr,arr2){
        this.arr = arr
        this.arr2 = arr2
    }
}